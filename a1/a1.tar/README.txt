How to compile program:
    make
How to execute program:
    ./geonorm <filename>