How to compile program:
    make
How to execute program:
    ./raytracer <camera model> <ply model(s)> <outfile name>
